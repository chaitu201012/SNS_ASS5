# Assignment 5 ( Intrusion detection system )

### Algorithms used

1) Random Forest
2) Logistic Regression
3) Support Vector Machine (SVM)
4) Naive Bayes
5) Decision Tree Classifier

### Split ratio 
->  Split ratio used is 66.67 : 33.33  
    So, Training set is 66.67%  
    and validation test is 33.33%  
    
### High accuracy model from the above
->  From the above models tested, we have got a better accuracy in RandomForest algorithm.
->  F1 score of 0.912 is obtained in RandomForest Algorithm on submission to AICROWD.

### Performance metrics
-> Performance metrics of the validation set which is calculated with the ML algorithms on the validation dataset are:
   1) Precision
   2) Recall
   3) F1 Score
   4) Acuracy Score
   
   
